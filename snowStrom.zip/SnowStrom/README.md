# Snowstorm

Custom editor for Minecraft Bedrock Edition particle files. Available as a web app and VSCode Extension:
* **Web App:** [github.com/JannisX11/snowstorm](https://jannisx11.github.io/snowstorm/)
* **VSCode Extension:** [Snowstorm - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=JannisX11.snowstorm)


## Interface

![Image](https://i.imgur.com/6QIlzcq.png)
